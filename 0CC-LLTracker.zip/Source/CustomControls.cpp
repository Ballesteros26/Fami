/*
** FamiTracker - NES/Famicom sound tracker
** Copyright (C) 2005-2014  Jonathan Liss
**
** 0CC-FamiTracker is (C) 2014-2018 HertzDevil
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
** Library General Public License for more details.  To obtain a
** copy of the GNU Library General Public License, write to the Free
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

#include "CustomControls.h"
#include "DPI.h"		// // //
#include "NumConv.h"		// // //

/*

 Contains some custom GUI controls.

 * CBannerEdit
   - An edit box that displays a banner when no text is present

 * CLockedEdit
   - An edit box that is locked for editing, unlocked with double-click

*/

///
/// CBannerEdit
///

const WCHAR CBannerEdit::BANNER_FONT[]	 = L"Tahoma";
const COLORREF CBannerEdit::BANNER_COLOR = 0x808080;

// Used to display a banner in edit boxes

IMPLEMENT_DYNAMIC(CBannerEdit, CEdit)

BEGIN_MESSAGE_MAP(CBannerEdit, CEdit)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

void CBannerEdit::OnSetFocus(CWnd* pOldWnd)
{
	CEdit::OnSetFocus(pOldWnd);
	Invalidate();
	RedrawWindow(NULL, NULL, RDW_ERASE);
}

void CBannerEdit::OnPaint()
{
	CEdit::OnPaint();

	// Overlay some text
	CStringW str;
	GetWindowTextW(str);

	// only if empty and not in focus
	if (str.GetLength() > 0 || GetFocus() == this)
		return;

	CDC *pDC = GetDC();
	if (pDC != NULL) {
		CFont font;
		font.CreateFontW(DPI::SY(12), 0, 0, 0, 0, TRUE, FALSE, FALSE, 0, 0, 0, 0, 0, BANNER_FONT);
		CFont *pOldFont = pDC->SelectObject(&font);

		pDC->SetBkColor(pDC->GetPixel(4, 4));
		pDC->SetTextColor(BANNER_COLOR);
		pDC->TextOutW(2, 1, m_strText);
		pDC->SelectObject(pOldFont);

		ReleaseDC(pDC);
	}
}

void CBannerEdit::OnKillFocus(CWnd* pNewWnd)
{
	CEdit::OnKillFocus(pNewWnd);
	// Limit string size to 31 chars
	CStringW text;
	GetWindowTextW(text);
	if (text.GetLength() > 31)
		text = text.Left(31);
	SetWindowTextW(text);
}

///
/// CLockedEdit
///

// This class takes care of locking/unlocking edit boxes by double clicking

IMPLEMENT_DYNAMIC(CLockedEdit, CEdit)

BEGIN_MESSAGE_MAP(CLockedEdit, CEdit)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

bool CLockedEdit::IsEditable() const
{
	return !((GetWindowLongW(m_hWnd, GWL_STYLE) & ES_READONLY) == ES_READONLY);
}

bool CLockedEdit::Update()
{
	bool ret_val(m_bUpdate);
	m_bUpdate = false;
	return ret_val;
}

int CLockedEdit::GetValue() const
{
	return m_iValue;
}

void CLockedEdit::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	m_bUpdate = false;
	if (IsEditable())
		SetSel(0, -1);	// select all
	else {
		SendMessageW(EM_SETREADONLY, FALSE);
		SetFocus();
		SetSel(0, -1);
	}
}

void CLockedEdit::OnSetFocus(CWnd* pOldWnd)
{
	CEdit::OnSetFocus(pOldWnd);

	if (!IsEditable())
		static_cast<CFrameWnd*>(AfxGetMainWnd())->GetActiveView()->SetFocus();		// // //
}

void CLockedEdit::OnKillFocus(CWnd* pNewWnd)
{
	CEdit::OnKillFocus(pNewWnd);
	CStringW Text;
	if (!IsEditable())
		return;
	GetWindowTextW(Text);
	m_iValue = conv::to_int(Text).value_or(0);
	m_bUpdate = true;
	SendMessageW(EM_SETREADONLY, TRUE);
}

BOOL CLockedEdit::PreTranslateMessage(MSG* pMsg)
{
	// For some reason OnKeyDown won't work
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) {
		static_cast<CFrameWnd*>(AfxGetMainWnd())->GetActiveView()->SetFocus();		// // //
		return TRUE;
	}

	return CEdit::PreTranslateMessage(pMsg);
}
