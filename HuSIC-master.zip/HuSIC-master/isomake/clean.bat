del *.iso
